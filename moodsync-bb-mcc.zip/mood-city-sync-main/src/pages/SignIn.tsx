import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { MapPin, Mail, Lock, User, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

const SignIn = () => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    confirmPassword: "",
    gender: "",
    interests: [] as string[],
    personality: ""
  });

  const interests = [
    "Fitness & Wellness", "Arts & Culture", "Food & Dining", 
    "Nightlife", "Outdoor Activities", "Technology", 
    "Music & Concerts", "Sports", "Shopping", "Study & Work"
  ];

  const personalityTypes = [
    "Introvert", "Extrovert", "Ambivert"
  ];

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleInterestToggle = (interest: string) => {
    setFormData(prev => ({
      ...prev,
      interests: prev.interests.includes(interest)
        ? prev.interests.filter(i => i !== interest)
        : [...prev.interests, interest]
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // This would connect to Supabase authentication
    console.log("Form submitted:", formData);
    alert("Demo mode: Connect to Supabase for full authentication!");
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-6 py-12">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center space-x-2">
            <MapPin className="w-8 h-8 text-accent" />
            <span className="text-2xl font-bold bg-gradient-primary bg-clip-text text-transparent">
              CitySync
            </span>
          </Link>
          <p className="text-foreground/70 mt-2">
            {isSignUp ? "Join the community" : "Welcome back"}
          </p>
        </div>

        <Card className="glass card-shadow p-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Email */}
            <div>
              <Label htmlFor="email" className="text-sm font-medium">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 w-4 h-4 text-foreground/50" />
                <Input
                  id="email"
                  type="email"
                  placeholder="your.email@example.com"
                  className="pl-10 glass"
                  value={formData.email}
                  onChange={(e) => handleInputChange("email", e.target.value)}
                  required
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <Label htmlFor="password" className="text-sm font-medium">Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 w-4 h-4 text-foreground/50" />
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  className="pl-10 glass"
                  value={formData.password}
                  onChange={(e) => handleInputChange("password", e.target.value)}
                  required
                />
              </div>
            </div>

            {/* Sign Up Additional Fields */}
            {isSignUp && (
              <>
                {/* Confirm Password */}
                <div>
                  <Label htmlFor="confirmPassword" className="text-sm font-medium">Confirm Password</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 w-4 h-4 text-foreground/50" />
                    <Input
                      id="confirmPassword"
                      type="password"
                      placeholder="••••••••"
                      className="pl-10 glass"
                      value={formData.confirmPassword}
                      onChange={(e) => handleInputChange("confirmPassword", e.target.value)}
                      required
                    />
                  </div>
                </div>

                {/* Gender */}
                <div>
                  <Label className="text-sm font-medium">Gender</Label>
                  <div className="grid grid-cols-3 gap-2 mt-2">
                    {["Male", "Female", "Other"].map((gender) => (
                      <Button
                        key={gender}
                        type="button"
                        variant={formData.gender === gender ? "accent" : "ghost"}
                        size="sm"
                        onClick={() => handleInputChange("gender", gender)}
                      >
                        {gender}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Personality Type */}
                <div>
                  <Label className="text-sm font-medium">Personality Type</Label>
                  <div className="grid grid-cols-3 gap-2 mt-2">
                    {personalityTypes.map((type) => (
                      <Button
                        key={type}
                        type="button"
                        variant={formData.personality === type ? "accent" : "ghost"}
                        size="sm"
                        onClick={() => handleInputChange("personality", type)}
                      >
                        {type}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Interests */}
                <div>
                  <Label className="text-sm font-medium">Interests (Select multiple)</Label>
                  <div className="grid grid-cols-2 gap-2 mt-2 max-h-32 overflow-y-auto">
                    {interests.map((interest) => (
                      <Button
                        key={interest}
                        type="button"
                        variant={formData.interests.includes(interest) ? "accent" : "ghost"}
                        size="sm"
                        className="text-xs h-8"
                        onClick={() => handleInterestToggle(interest)}
                      >
                        {interest}
                      </Button>
                    ))}
                  </div>
                </div>
              </>
            )}

            {/* Submit Button */}
            <Button type="submit" variant="hero" className="w-full">
              {isSignUp ? "Create Account" : "Sign In"}
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </form>

          {/* Toggle Sign In/Up */}
          <div className="mt-6">
            <Separator className="my-4" />
            <div className="text-center">
              <Button
                variant="ghost"
                onClick={() => setIsSignUp(!isSignUp)}
                className="text-sm"
              >
                {isSignUp 
                  ? "Already have an account? Sign in" 
                  : "Need an account? Sign up"
                }
              </Button>
            </div>
          </div>

          {/* Demo Notice */}
          <div className="mt-4 p-3 glass rounded-lg">
            <p className="text-xs text-center text-foreground/60">
              <strong>Demo Mode:</strong> Connect to Supabase for full authentication functionality
            </p>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default SignIn;