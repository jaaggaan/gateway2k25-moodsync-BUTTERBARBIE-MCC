import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { Brain, Coffee, Music, Sunset, Zap, Heart } from "lucide-react";

interface MoodOption {
  id: string;
  name: string;
  icon: React.ReactNode;
  color: string;
  description: string;
}

const moodOptions: MoodOption[] = [
  {
    id: "calm",
    name: "Calm & Peaceful",
    icon: <Heart className="w-6 h-6" />,
    color: "mood-calm",
    description: "Looking for quiet spaces to relax"
  },
  {
    id: "energetic",
    name: "Energetic & Social",
    icon: <Zap className="w-6 h-6" />,
    color: "mood-energetic",
    description: "Ready to meet people and have fun"
  },
  {
    id: "focused",
    name: "Focused & Productive",
    icon: <Brain className="w-6 h-6" />,
    color: "mood-neutral",
    description: "Need a good workspace or study spot"
  },
  {
    id: "creative",
    name: "Creative & Inspired",
    icon: <Music className="w-6 h-6" />,
    color: "bg-purple-500",
    description: "Seeking artistic or cultural experiences"
  },
  {
    id: "chill",
    name: "Chill & Casual",
    icon: <Coffee className="w-6 h-6" />,
    color: "bg-amber-500",
    description: "Just want to hang out somewhere nice"
  },
  {
    id: "romantic",
    name: "Romantic & Intimate",
    icon: <Sunset className="w-6 h-6" />,
    color: "bg-pink-500",
    description: "Perfect for dates or special moments"
  }
];

interface MoodSelectorProps {
  onMoodSelect: (mood: string) => void;
  selectedMood?: string;
}

const MoodSelector = ({ onMoodSelect, selectedMood }: MoodSelectorProps) => {
  const [currentMood, setCurrentMood] = useState(selectedMood || "");
  const navigate = useNavigate();

  const handleMoodSelect = (moodId: string) => {
    setCurrentMood(moodId);
    onMoodSelect(moodId);
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold mb-2">How are you feeling?</h2>
        <p className="text-foreground/70">Tell us your vibe and we'll find the perfect spots for you</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {moodOptions.map((mood) => (
          <Card
            key={mood.id}
            className={`p-6 cursor-pointer transition-smooth hover:scale-105 card-shadow ${
              currentMood === mood.id 
                ? 'ring-2 ring-accent bg-accent/10' 
                : 'glass hover:bg-white/10'
            }`}
            onClick={() => handleMoodSelect(mood.id)}
          >
            <div className="flex flex-col items-center text-center space-y-3">
              <div className={`w-12 h-12 rounded-full ${mood.color} flex items-center justify-center text-white`}>
                {mood.icon}
              </div>
              <h3 className="font-semibold text-lg">{mood.name}</h3>
              <p className="text-sm text-foreground/60">{mood.description}</p>
            </div>
          </Card>
        ))}
      </div>
      
      {currentMood && (
        <div className="text-center">
          <Button 
            variant="hero" 
            size="lg" 
            className="px-8"
            onClick={() => navigate("/signin")}
          >
            Find My Spots
          </Button>
        </div>
      )}
    </div>
  );
};

export default MoodSelector;