import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Coins, TrendingUp, Gift, Target } from "lucide-react";

interface MoodCoinDisplayProps {
  coins: number;
  todayEarned: number;
  streak: number;
}

const MoodCoinDisplay = ({ coins, todayEarned, streak }: MoodCoinDisplayProps) => {
  return (
    <Card className="glass card-shadow p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold">Mood Coins</h3>
        <Coins className="w-6 h-6 text-accent" />
      </div>
      
      {/* Main Balance */}
      <div className="text-center mb-6">
        <Button 
          variant="ghost" 
          className="text-4xl font-bold p-4 h-auto"
          onClick={() => window.location.href = '/signin'}
        >
          <Coins className="w-8 h-8 text-accent mr-2" />
          <span className="text-accent">{coins.toLocaleString()}</span>
        </Button>
        <p className="text-foreground/60 text-sm">Mood Coins Balance</p>
      </div>
      
      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="text-center">
          <div className="flex items-center justify-center mb-2">
            <TrendingUp className="w-4 h-4 text-mood-energetic mr-1" />
            <span className="text-xl font-semibold text-mood-energetic">+{todayEarned}</span>
          </div>
          <p className="text-xs text-foreground/60">Today</p>
        </div>
        
        <div className="text-center">
          <div className="flex items-center justify-center mb-2">
            <Target className="w-4 h-4 text-mood-calm mr-1" />
            <span className="text-xl font-semibold text-mood-calm">{streak}</span>
          </div>
          <p className="text-xs text-foreground/60">Day Streak</p>
        </div>
      </div>
      
      {/* Earning Methods */}
      <div className="space-y-2 mb-4">
        <div className="flex items-center justify-between text-sm">
          <span className="text-foreground/70">Check mood daily</span>
          <span className="text-accent font-medium">+10</span>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-foreground/70">Join community event</span>
          <span className="text-accent font-medium">+25</span>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-foreground/70">Share location review</span>
          <span className="text-accent font-medium">+15</span>
        </div>
      </div>
      
      {/* Redeem Button */}
      <Button 
        variant="hero" 
        size="sm" 
        className="w-full"
        onClick={() => window.location.href = '/signin'}
      >
        <Gift className="w-4 h-4 mr-2" />
        Redeem Rewards
      </Button>
    </Card>
  );
};

export default MoodCoinDisplay;