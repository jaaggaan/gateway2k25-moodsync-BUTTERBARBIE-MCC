import { Button } from "@/components/ui/button";
import { MapPin, User, Settings, Bell } from "lucide-react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

const Navigation = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navigate = useNavigate();
  
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass border-b border-white/20">
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <MapPin className="w-8 h-8 text-accent" />
            <span className="text-2xl font-bold bg-gradient-primary bg-clip-text text-transparent">
              CitySync
            </span>
          </div>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-6">
            <Button 
              variant="ghost" 
              className="text-foreground/80 hover:text-foreground"
              onClick={() => navigate("/signin")}
            >
              Discover
            </Button>
            <Button 
              variant="ghost" 
              className="text-foreground/80 hover:text-foreground"
              onClick={() => navigate("/signin")}
            >
              Events
            </Button>
            <Button 
              variant="ghost" 
              className="text-foreground/80 hover:text-foreground"
              onClick={() => navigate("/signin")}
            >
              Community
            </Button>
          </div>
          
          {/* User Actions */}
          <div className="flex items-center space-x-3">
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="w-5 h-5" />
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-mood-energetic rounded-full text-xs" />
            </Button>
            <Button variant="ghost" size="icon" onClick={() => navigate("/signin")}>
              <Settings className="w-5 h-5" />
            </Button>
            <Button variant="ghost" size="icon" onClick={() => navigate("/signin")}>
              <User className="w-5 h-5" />
            </Button>
            <Button variant="accent" size="sm" onClick={() => navigate("/signin")}>
              Sign In
            </Button>
          </div>
          
          {/* Mobile Menu Button */}
          <Button 
            variant="ghost" 
            size="icon"
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <div className="w-6 h-6 flex flex-col justify-center items-center">
              <span className={`block w-5 h-0.5 bg-foreground transition-transform ${isMenuOpen ? 'rotate-45 translate-y-1' : ''}`} />
              <span className={`block w-5 h-0.5 bg-foreground mt-1 transition-opacity ${isMenuOpen ? 'opacity-0' : ''}`} />
              <span className={`block w-5 h-0.5 bg-foreground mt-1 transition-transform ${isMenuOpen ? '-rotate-45 -translate-y-1' : ''}`} />
            </div>
          </Button>
        </div>
        
        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4 border-t border-white/20">
            <div className="flex flex-col space-y-2 pt-4">
              <Button variant="ghost" className="justify-start" onClick={() => navigate("/signin")}>Discover</Button>
              <Button variant="ghost" className="justify-start" onClick={() => navigate("/signin")}>Events</Button>
              <Button variant="ghost" className="justify-start" onClick={() => navigate("/signin")}>Community</Button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navigation;