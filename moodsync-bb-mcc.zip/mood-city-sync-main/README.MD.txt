Installation Guide
To run the MoodSync application locally, follow these steps:
1. Clone the repository:
   git clone <repository-url>
2. Navigate to the project directory:
   cd moodsync
3. Install the required dependencies:
   npm install
4. Run the development server:
   npm run dev
5. Open the app in your browser at:
   http://localhost:5173
Usage Instructions
1. Open the app in your browser.
2. Create a profile by signing up or logging in.
3. Enter your mood manually or use the camera detection feature.
4. View recommendations for events and places suited to your mood.
5. Track mood coins, streaks, and explore the interactive map.
